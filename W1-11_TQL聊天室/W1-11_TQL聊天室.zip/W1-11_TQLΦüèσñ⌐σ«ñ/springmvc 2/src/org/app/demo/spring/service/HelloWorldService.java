package org.app.demo.spring.service;  
  
public interface HelloWorldService {  
  
       public String getNewName(String userName);  
  
} 